<?php
/**
 * ================================================================
 * ANTV Router - Điều phối luồng: Lịch phát -> World Cup -> Fallback ABR
 * ================================================================
 */

error_reporting(0);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Ho_Chi_Minh');

// ===== CORS - BẮT BUỘC CHO WEB PLAYER / APP =====
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Max-Age: 86400");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    exit();
}

// Cache ngắn 5s - phù hợp cho router luôn kiểm tra realtime
header("Cache-Control: max-age=5, must-revalidate");
header("Expires: " . gmdate('D, d M Y H:i:s', time() + 5) . ' GMT');

// ================= CẤU HÌNH =================
$VTV6_URL      = 'https://devda.undo.it/Stream/index.php?id=vtv6&ext=.m3u8';
$FALLBACK_URL  = 'https://xeno.env.pm/play.php/index.m3u8';
$EPG_API_URL   = 'https://vnepg.site/api/schedule/vtv6hd';
$SCHEDULE_FILE = __DIR__ . '/schedule.json';
$LOG_DIR       = __DIR__ . '/Log';

// ================= HÀM TIỆN ÍCH =================
function load_schedules($file_path) {
    if (!file_exists($file_path)) return [];
    $content = @file_get_contents($file_path);
    if (!$content) return [];
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

function write_log($msg) {
    global $LOG_DIR;
    if (!is_dir($LOG_DIR)) @mkdir($LOG_DIR, 0755, true);
    @error_log("[" . date('Y-m-d H:i:s') . "] $msg\n", 3, $LOG_DIR . '/antv.log');
}

function is_world_cup_on($api_url) {
    global $LOG_DIR;
    $cache_file = $LOG_DIR . '/wc_cache.txt';
    if (!is_dir($LOG_DIR)) @mkdir($LOG_DIR, 0755, true);

    // Cache 5 phút để tránh gọi API liên tục
    if (file_exists($cache_file) && (time() - filemtime($cache_file) < 300)) {
        return @file_get_contents($cache_file) === '1';
    }

    if (!function_exists('curl_init')) return false;

    $ch = curl_init($api_url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_CONNECTTIMEOUT => 3,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    $response  = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200 || !$response) {
        @file_put_contents($cache_file, '0');
        return false;
    }

    $json = json_decode($response, true);
    if (!$json) return false;

    $events = $json['data']['program'] ?? $json['data'] ?? $json['events'] ?? [];
    $wc_keywords = ['world cup', 'worldcup', 'wc', 'vòng loại', 'bán kết', 'chung kết'];
    $is_wc = false;

    foreach ($events as $event) {
        $title = strtolower(json_encode($event, JSON_UNESCAPED_UNICODE));
        foreach ($wc_keywords as $kw) {
            if (stripos($title, $kw) !== false) {
                $is_wc = true;
                break 2;
            }
        }
    }

    @file_put_contents($cache_file, $is_wc ? '1' : '0');
    return $is_wc;
}

// ================= LOGIC ĐIỀU HƯỚNG =================
write_log("=== Request Started ===");
$schedules    = load_schedules($SCHEDULE_FILE);
$now          = time();
$current_date = date('Y-m-d');
$target_url   = '';

// Bước 1: Kiểm tra lịch phát trong schedule.json (hỗ trợ lịch xuyên đêm)
foreach ($schedules as $schedule) {
    $day   = $schedule['day'] ?? '';
    $start = $schedule['start_time'] ?? '';
    $end   = $schedule['end_time'] ?? '';
    $url   = $schedule['m3u8_url'] ?? '';

    if (empty($start) || empty($end) || empty($url)) continue;

    if (preg_match('/^\d{2}:\d{2}$/', $start)) $start .= ':00';
    if (preg_match('/^\d{2}:\d{2}$/', $end))   $end   .= ':00';

    if ($day !== 'all' && $day !== $current_date) continue;

    $start_ts = strtotime($current_date . ' ' . $start);
    $end_ts   = strtotime($current_date . ' ' . $end);
    if ($end_ts <= $start_ts) $end_ts += 86400; // Xuyên đêm

    // Trường hợp lịch bắt đầu từ hôm qua kéo dài sang hôm nay
    if ($now < $start_ts) {
        $prev_start_ts = $start_ts - 86400;
        $prev_end_ts   = $end_ts - 86400;
        if ($now >= $prev_start_ts && $now < $prev_end_ts) {
            $target_url = $url;
            write_log("✓ Active overnight schedule (carried from yesterday): " . ($schedule['name'] ?? 'Unknown'));
            break;
        }
    }

    if ($now >= $start_ts && $now < $end_ts) {
        $target_url = $url;
        write_log("✓ Found active schedule: " . ($schedule['name'] ?? 'Unknown'));
        break;
    }
}

// Bước 2: Không có lịch -> kiểm tra World Cup qua EPG
if (empty($target_url) && is_world_cup_on($EPG_API_URL)) {
    $target_url = $VTV6_URL;
    write_log("✓ World Cup active -> VTV6");
}

// Bước 3: Không có gì -> fallback về ABR master playlist
if (empty($target_url)) {
    $target_url = $FALLBACK_URL;
    write_log("✓ No schedule/WC -> Fallback to play.php ABR");
}

write_log("Redirecting to: $target_url");
header("Location: " . $target_url, true, 302);
exit;