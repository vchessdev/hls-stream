<?php
error_reporting(0);
ini_set('display_errors', 0);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/vnd.apple.mpegurl");
header("Cache-Control: max-age=2, must-revalidate");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("HTTP/1.1 200 OK");
    exit();
}

$quality = $_GET['quality'] ?? '1080p';
if (!in_array($quality, ['1080p', '360p'], true)) $quality = '1080p';

$segment_duration = 4;
$total_segments   = 95;

// Pin cứng vào commit cụ thể -> jsDelivr cache VĨNH VIỄN, không hết hạn, không cold-cache
$commit_hash = "809c5a03750df81e73d8a6e3f352c02e7b62f109";
$cdn_base    = "https://cdn.jsdelivr.net/gh/vchessdev/hls-stream@{$commit_hash}/hoanthanh";

$time_now       = time();
$media_sequence = intdiv($time_now, $segment_duration);
$current_index  = $media_sequence % $total_segments;

$buffer_count = 10;

echo "#EXTM3U\n";
echo "#EXT-X-VERSION:3\n";
echo "#EXT-X-TARGETDURATION:" . ($segment_duration + 1) . "\n";
echo "#EXT-X-MEDIA-SEQUENCE:" . $media_sequence . "\n\n";

for ($i = 0; $i < $buffer_count; $i++) {
    $idx = sprintf("%03d", ($current_index + $i) % $total_segments);
    echo "#EXTINF:" . number_format($segment_duration, 6) . ",\n";
    echo $cdn_base . "/{$quality}/finished_{$idx}.ts\n";
}
exit;